<?php $this->need('header.php'); ?>
<div class="obox center alert danger"><h2>404 NOT FOUND</h2><br>该页面不存在，请检查您输入的URL或尝试搜索<hr><a href="<?php $this->options->siteUrl(); ?>">返回首页</a></div>
<?php $this->need('footer.php'); ?>